#pragma once
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GL/glew.h>            // GLEW library
#include <camera.h> // Camera class

//This class is used to draw/move cubes in the model
#ifndef CUBE_H
#define CUBE_H
class Cube
{
private:
	glm::vec3 gColor;
	glm::vec3 gPosition;
	glm::vec3 gScale;
	float degreesToRadians(float degreeAngle);
public:
	Cube(double xScale, double yScale, double zScale, double xLoc, double yLoc, double zLoc, double rColor, double gColor, double bColor);
	glm::mat4 moveCube(float xAngle, float yAngle, float zAngle);
	glm::vec3 getObjectColor();
};

#endif