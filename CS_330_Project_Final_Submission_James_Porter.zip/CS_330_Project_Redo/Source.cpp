﻿#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"      // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <camera.h> // Camera class
#include "Cube.h"
#include "Cylinder.h"
#include "Light.h"

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "CS 330 Graphics Project: The Grand Finale!"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbo;         // Handle for the vertex buffer object
        GLuint nVertices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    // Cube mesh data
    GLMesh gCubeMesh;
    GLMesh gTorusMesh;
    GLMesh gCylinderMesh;

    // Texture IDS
    GLuint gFloorTextureId;
    GLuint gWallTextureId;
    GLuint gStageTextureId;
    GLuint gTableclothTextureId;
    GLuint gLightTextureId;
    GLuint gStandTextureId;
    GLuint gMixerTextureId;
    GLuint gComputerTextureId;
    GLuint gSpeakerTextureId;

    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Shader programs
    GLuint gObjectProgramId;
    GLuint gLampProgramId;

    // camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 7.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    GLint objectColorLoc;
    GLint lightColorLoc;
    GLint lightPositionLoc;
    GLint viewPositionLoc;
    GLint modelLoc;
    GLint viewLoc;
    GLint projLoc;
    glm::mat4 model;
    glm::mat4 view;
    glm::mat4 projection;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateCylinderMesh(GLMesh& mesh);
void UCreateCubeMesh(GLMesh& mesh);
void UCreateCubeTorusMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void setupObject();
void setupObjectColor(glm::vec3 gObjectColor, glm::vec3 gLightColor, glm::vec3 gLightPosition);
void setupLight();


/* Cube Vertex Shader Source Code*/
const GLchar* cubeVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Cube Fragment Shader Source Code*/
const GLchar* cubeFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.1f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Cube Fragment Shader Source Code*/
const GLchar* cubeFragmentShaderSourceFill = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.8f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.15f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);


/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);


// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    // Calls the function to create the Vertex Buffer Object
    UCreateCubeMesh(gCubeMesh);
    UCreateCubeTorusMesh(gTorusMesh);
    UCreateCylinderMesh(gCylinderMesh);

    // Create the shader programs
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gObjectProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // Load floor texture
    const char* texFilename = "textures/floor.jpg";
    if (!UCreateTexture(texFilename, gFloorTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    // Load Stage texture
    texFilename = "textures/stage.jpg";
    if (!UCreateTexture(texFilename, gStageTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    // Load Wall texture
    texFilename = "textures/wall.jpg";
    if (!UCreateTexture(texFilename, gWallTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    // Load Speaker texture
    texFilename = "textures/speakerGrid.jpg";
    if (!UCreateTexture(texFilename, gSpeakerTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    // Load Table texture
    texFilename = "textures/table.jpg";
    if (!UCreateTexture(texFilename, gTableclothTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    // Load light texture
    texFilename = "textures/light.jpg";
    if (!UCreateTexture(texFilename, gLightTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    // Load stand texture
    texFilename = "textures/stand.jpg";
    if (!UCreateTexture(texFilename, gStandTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    // Load mixer texture
    texFilename = "textures/mixer.jpg";
    if (!UCreateTexture(texFilename, gMixerTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    // Load computer texture
    texFilename = "textures/computer.jpg";
    if (!UCreateTexture(texFilename, gComputerTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    cout << texFilename << " Found" << endl;
    
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gObjectProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gObjectProgramId, "uTexture"), 0);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gCubeMesh);
    UDestroyMesh(gTorusMesh);
    UDestroyMesh(gCylinderMesh);

    // Release texture
    UDestroyTexture(gFloorTextureId);

    // Release shader programs
    UDestroyShaderProgram(gObjectProgramId);
    UDestroyShaderProgram(gLampProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    //Move according tot he button pushed
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UPWARDS, gDeltaTime);

    //Adjust the view using the p button
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        glOrtho(0, WINDOW_WIDTH, 0, WINDOW_HEIGHT, 20.0, 20.0);
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Activate the cylinder VAO (used by cylinder objects)
    glBindVertexArray(gCylinderMesh.vao);

    // LAMP: draw ceiling light 1
    //----------------
    glUseProgram(gLampProgramId);

    Light ceilingLight1(1.0, 0.1, -6.0, 10.5, 6.5, 0.5, 0.5, 0.5);
    model = ceilingLight1.moveLight(0.0, 0.0, 0.0);

    glm::vec3 gLightColor = ceilingLight1.getObjectColor();

    setupLight();

    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    Light ceilingLight2(1.0, 0.1, 2.5, 10.5, -1.5, 0.5, 0.5, 0.5);
    model = ceilingLight2.moveLight(0.0, 0.0, 0.0);

    setupLight();

    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    Light ceilingLight3(1.0, 0.1, 11.0, 10.5, 7.0, 0.5, 0.5, 0.5);
    model = ceilingLight3.moveLight(0.0, 0.0, 0.0);

    setupLight();

    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    Light ceilingLight4(1.0, 0.1, 2.5, 10.5, 15.0, 0.5, 0.5, 0.5);
    model = ceilingLight4.moveLight(0.0, 0.0, 0.0);

    setupLight();

    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    // Activate the cube VAO (used by the window lamp)
    glBindVertexArray(gCubeMesh.vao);

    // LAMP: draw window light
    //----------------
    //Transform the smaller cube used as a visual que for the light source
    Light windowLight(0.1, 5.0, 3.0, 25.0, 5.0, -8.25, 0.5, 0.5, 0.5);
    model = windowLight.moveLight(0.0, -45.0, 0.0);

    setupLight();

    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Activate the cube VAO (used by cube and lamp)
    glBindVertexArray(gCubeMesh.vao);

    // Set the shader to be used
    glUseProgram(gObjectProgramId);

    // CUBE: draw stage
    //----------------
    Cube stageObject(21.0, 2.0, 11.0, 0.0, 0.0, 0.0, 1.0, 0.2, 0.0);
    model = stageObject.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(stageObject.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(stageObject.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(stageObject.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(stageObject.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    GLint UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gStageTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // CUBE: draw floor
    //----------------
    Cube floorObject(50.0, 0.1, 50.0, 0.0, -0.5, 0.0, 1.0, 0.2, 0.0);
    model = floorObject.moveCube(0.0, -45.0, 0.0);

    setupObject();
    setupObjectColor(floorObject.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(floorObject.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(floorObject.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(floorObject.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gFloorTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw wall 1
    //----------------
    Cube wall1Object(0.1, 15.0, 50.0, 17.0, 7.0, -17.0, 1.0, 0.2, 0.0);
    model = wall1Object.moveCube(0.0, -45.0, 0.0);

    setupObject();
    setupObjectColor(wall1Object.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(wall1Object.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(wall1Object.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(wall1Object.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gWallTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw wall 2
    //----------------
    Cube wall2Object(0.1, 15.0, 49.0, -16.0, 7.0, -16.0, 1.0, 0.2, 0.0);
    model = wall2Object.moveCube(0.0, 50.0, 0.0);

    setupObject();
    setupObjectColor(wall2Object.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(wall2Object.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(wall2Object.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(wall2Object.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw speaker 1
    //----------------
    Cube speaker1Object(1.25, 2.0, 1.0, 7.5, 8.0, 3.75, 1.0, 0.2, 0.0);
    model = speaker1Object.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(speaker1Object.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(speaker1Object.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(speaker1Object.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(speaker1Object.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gSpeakerTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw speaker 2
    //----------------
    Cube speaker2Object(1.25, 2.0, 1.0, -7.5, 8.0, 3.75, 1.0, 0.2, 0.0);
    model = speaker2Object.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(speaker2Object.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(speaker2Object.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(speaker2Object.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(speaker2Object.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw light base 1
    //----------------
    Cube lightBase1(0.75, 0.5, 0.75, -5.0, 1.0, 4.0, 1.0, 0.2, 0.0);
    model = lightBase1.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(lightBase1.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(lightBase1.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(lightBase1.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(lightBase1.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gLightTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw light base 2
    //----------------
    Cube lightBase2(0.75, 0.5, 0.75, 5.0, 1.0, 4.0, 1.0, 0.2, 0.0);
    model = lightBase2.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(lightBase2.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(lightBase2.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(lightBase2.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(lightBase2.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw Table
    //----------------
    Cube table(7.0, 4.0, 3.0, 0.0, 2.0, 3.25, 1.0, 0.2, 0.0);
    model = table.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(table.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(table.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(table.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(table.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTableclothTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw Mixer 1
    //----------------
    Cube mixer1(2.0, 0.75, 1.5, 0.0, 4.0, 3.5, 1.0, 0.2, 0.0);
    model = mixer1.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(mixer1.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(mixer1.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(mixer1.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(mixer1.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gMixerTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw Mixer 2
    //----------------
    Cube mixer2(2.0, 0.25, 1.5, 0.0, 4.5, 4.0, 1.0, 0.2, 0.0);
    model = mixer2.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(mixer2.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(mixer2.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(mixer2.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(mixer2.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw Computer 1
    //----------------
    Cube computer1(1.25, 0.1, 0.9, 0.0, 4.65, 4.0, 1.0, 0.2, 0.0);
    model = computer1.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(computer1.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(computer1.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(computer1.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(computer1.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gComputerTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw Computer 2
    //----------------
    Cube computer2(1.25, 1.1, 0.1, 0.0, 5.0, 4.5, 1.0, 0.2, 0.0);
    model = computer2.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(computer2.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(computer2.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(computer2.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(computer2.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Cube: draw back light
    //----------------
    Cube backLight(6.0, 0.75, 0.25, 0.0, 9.0, -2.0, 1.0, 0.2, 0.0);
    model = backLight.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(backLight.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(backLight.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(backLight.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(backLight.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gLightTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Activate the torus VAO (used by torus objects)
    glBindVertexArray(gTorusMesh.vao);

    // Torus: draw light connector 1
    //----------------
    Cube light1Torus(0.25, 0.25, 0.1, 5.0, 1.5, 4.0, 1.0, 0.2, 0.0);
    model = light1Torus.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(light1Torus.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(light1Torus.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(light1Torus.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(light1Torus.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gTorusMesh.nVertices);

    // Torus: draw light connector 2
    //----------------
    Cube light2Torus(0.25, 0.25, 0.1, -5.0, 1.5, 4.0, 1.0, 0.2, 0.0);
    model = light2Torus.moveCube(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(light2Torus.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(light2Torus.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(light2Torus.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(light2Torus.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gTorusMesh.nVertices);

    // Activate the cylinder VAO (used by cylinder objects)
    glBindVertexArray(gCylinderMesh.vao);

    // Cylinder: draw back tripod (4 Parts)
    //----------------
    Cylinder backTripod(0.1, 6.0, 0.0, 6.0, -2.0, 1.0, 0.2, 0.0);
    model = backTripod.moveCylinder(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(backTripod.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(backTripod.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(backTripod.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(backTripod.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gStandTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 2
    Cylinder backTripod1(0.1, 3.5, 0.0, 2.0, -0.6, 1.0, 0.2, 0.0);
    model = backTripod1.moveCylinder(55.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(backTripod1.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(backTripod1.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(backTripod1.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(backTripod1.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 3
    Cylinder backTripod2(0.1, 3.9, -1.5, 2.1, -2.7, 1.0, 0.2, 0.0);
    model = backTripod2.moveCylinder(-35.0, 0.0, 55.0);

    setupObject();
    setupObjectColor(backTripod2.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(backTripod2.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(backTripod2.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(backTripod2.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 4
    Cylinder backTripod3(0.1, 3.9, 1.5, 2.1, -2.7, 1.0, 0.2, 0.0);
    model = backTripod3.moveCylinder(-35.0, 0.0, -55.0);

    setupObject();
    setupObjectColor(backTripod3.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(backTripod3.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(backTripod3.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(backTripod3.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    // Cylinder: draw right tripod (4 Parts)
    //----------------
    Cylinder rightTripod(0.1, 5.0, 7.5, 5.0, 3.75, 1.0, 0.2, 0.0);
    model = rightTripod.moveCylinder(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(rightTripod.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(rightTripod.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(rightTripod.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(rightTripod.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 2
    Cylinder rightTripod1(0.1, 3.5, 7.5, 1.5, 2.35, 1.0, 0.2, 0.0);
    model = rightTripod1.moveCylinder(-55.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(rightTripod1.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(rightTripod1.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(rightTripod1.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(rightTripod1.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 3
    Cylinder rightTripod2(0.1, 3.5, 6.1, 1.7, 4.35, 1.0, 0.2, 0.0);
    model = rightTripod2.moveCylinder(35.0, 0.0, 55.0);

    setupObject();
    setupObjectColor(rightTripod2.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(rightTripod2.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(rightTripod2.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(rightTripod2.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 4
    Cylinder rightTripod3(0.1, 3.5, 8.8, 1.7, 4.35, 1.0, 0.2, 0.0);
    model = rightTripod3.moveCylinder(35.0, 0.0, -55.0);

    setupObject();
    setupObjectColor(rightTripod3.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(rightTripod3.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(rightTripod3.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(rightTripod3.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    // Cylinder: draw Left tripod (4 Parts)
    //----------------
    Cylinder leftTripod(0.1, 5.0, -7.5, 5.0, 3.75, 1.0, 0.2, 0.0);
    model = leftTripod.moveCylinder(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(leftTripod.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(leftTripod.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(leftTripod.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(leftTripod.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 2
    Cylinder leftTripod1(0.1, 3.5, -7.5, 1.5, 2.35, 1.0, 0.2, 0.0);
    model = leftTripod1.moveCylinder(-55.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(leftTripod1.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(leftTripod1.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(leftTripod1.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(leftTripod1.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 3
    Cylinder leftTripod2(0.1, 3.5, -6.1, 1.7, 4.35, 1.0, 0.2, 0.0);
    model = leftTripod2.moveCylinder(35.0, 0.0, -55.0);

    setupObject();
    setupObjectColor(leftTripod2.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(leftTripod2.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(leftTripod2.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(leftTripod2.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    //Part 4
    Cylinder leftTripod3(0.1, 3.5, -8.8, 1.7, 4.35, 1.0, 0.2, 0.0);
    model = leftTripod3.moveCylinder(35.0, 0.0, 55.0);

    setupObject();
    setupObjectColor(leftTripod3.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(leftTripod3.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(leftTripod3.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(leftTripod3.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    // Cylinder: draw Left floor light (4 Parts)
    //----------------
    Cylinder leftFloorLight(0.20, 0.5, -5.0, 1.75, 4.0, 1.0, 0.2, 0.0);
    model = leftFloorLight.moveCylinder(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(leftFloorLight.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(leftFloorLight.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(leftFloorLight.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(leftFloorLight.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gLightTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    // Cylinder: draw right floor light (4 Parts)
    //----------------
    Cylinder rightFloorLight(0.20, 0.5, 5.0, 1.75, 4.0, 1.0, 0.2, 0.0);
    model = rightFloorLight.moveCylinder(0.0, 0.0, 0.0);

    setupObject();
    setupObjectColor(rightFloorLight.getObjectColor(), gLightColor, ceilingLight1.getLightPosition());
    setupObjectColor(rightFloorLight.getObjectColor(), gLightColor, ceilingLight2.getLightPosition());
    setupObjectColor(rightFloorLight.getObjectColor(), gLightColor, ceilingLight3.getLightPosition());
    setupObjectColor(rightFloorLight.getObjectColor(), gLightColor, ceilingLight4.getLightPosition());

    UVScaleLoc = glGetUniformLocation(gObjectProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gWallTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCylinderMesh.nVertices);

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// Implements the UCreateCylinderMesh function
void UCreateCylinderMesh(GLMesh& mesh)
{
    // Position and Color data
    GLfloat verts[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Height triangles
        //Rectangle 1               //Negative Z Normal     Texture Coords.
        1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        1.0f,  -0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        1.0f,  -0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.985f,-0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        //Rectangle 2               //Negative Z Normal     Texture Coords.
        0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.940f,-0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.940f,-0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.985f,-0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 3               //Negative Z Normal     Texture Coords.
        0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.866f,-0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.866f,-0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.940f,-0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 4               //Negative Z Normal     Texture Coords.
        0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.766f,-0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.766f,-0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.866f,-0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 5               //Negative Z Normal     Texture Coords.
        0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.643f,-0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.643f,-0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.766f,-0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 6               //Negative Z Normal     Texture Coords.
        0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.5f,  -0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.5f,  -0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.643f,-0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 7               //Negative Z Normal     Texture Coords.
        0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.342f,-0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.342f,-0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.5f,  -0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 8               //Negative Z Normal     Texture Coords.
        0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.174f,-0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.174f,-0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.342f,-0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 9               //Negative Z Normal     Texture Coords.
        0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.0f,   0.5f,  1.0f,        0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.0f,  -0.5f,  1.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.0f,  -0.5f,  1.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.174f,-0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 10              //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  1.0f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.174f,-0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.174f,-0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.0f,  -0.5f,  1.0f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.0f,   0.5f,  1.0f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 11              //Negative Z Normal     Texture Coords.
       -0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.342f,-0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.342f,-0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.174f,-0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 12              //Negative Z Normal     Texture Coords.
       -0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.5f,  -0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.5f,  -0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.342f,-0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 13              //Negative Z Normal     Texture Coords.
       -0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.643f,-0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.643f,-0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.5f,  -0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 14              //Negative Z Normal     Texture Coords.
       -0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.766f,-0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.766f,-0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.643f,-0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 15              //Negative Z Normal     Texture Coords.
       -0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.866f,-0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.866f,-0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.766f,-0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 16              //Negative Z Normal     Texture Coords.
       -0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.940f,-0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.940f,-0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.866f,-0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 17              //Negative Z Normal     Texture Coords.
       -0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.985f,-0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.985f,-0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.940f,-0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 18              //Negative Z Normal     Texture Coords.
       -0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -1.0f,  -0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -1.0f,  -0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.985f,-0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 19              //Negative Z Normal     Texture Coords.
       -1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.985f, 0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.985f,-0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.985f,-0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -1.0f,  -0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 20              //Negative Z Normal     Texture Coords.
       -0.985f, 0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.940f, 0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.940f,-0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.940f,-0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.985f,-0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.985f, 0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 21              //Negative Z Normal     Texture Coords.
       -0.940f, 0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.866f, 0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.866f,-0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.866f,-0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.940f,-0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.940f, 0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 22              //Negative Z Normal     Texture Coords.
       -0.866f, 0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.766f, 0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.766f,-0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.766f,-0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.866f,-0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.866f, 0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 23              //Negative Z Normal     Texture Coords.
       -0.766f, 0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.643f, 0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.643f,-0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.643f,-0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.766f,-0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.766f, 0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 24              //Negative Z Normal     Texture Coords.
       -0.643f, 0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.5f,   0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.5f,  -0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.5f,  -0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.643f,-0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.643f, 0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 25              //Negative Z Normal     Texture Coords.
       -0.5f,   0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.342f, 0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.342f,-0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.342f,-0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.5f,  -0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.5f,   0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 26              //Negative Z Normal     Texture Coords.
       -0.342f, 0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
       -0.174f, 0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
       -0.174f,-0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.174f,-0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.342f,-0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.342f, 0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 27              //Negative Z Normal     Texture Coords.
       -0.174f, 0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.0f,   0.5f, -1.0f,        0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.0f,  -0.5f, -1.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.0f,  -0.5f, -1.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
       -0.174f,-0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
       -0.174f, 0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 28              //Negative Z Normal     Texture Coords.
        0.0f,   0.5f, -1.0f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.174f, 0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.174f,-0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.174f,-0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.0f,  -0.5f, -1.0f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.0f,   0.5f, -1.0f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 28              //Negative Z Normal     Texture Coords.
        0.174f, 0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.342f, 0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.342f,-0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.342f,-0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.174f,-0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.174f, 0.5f, -0.985f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 29              //Negative Z Normal     Texture Coords.
        0.342f, 0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.5f,   0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.5f,  -0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.5f,  -0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.342f,-0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.342f, 0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 30              //Negative Z Normal     Texture Coords.
        0.5f,   0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.643f, 0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.643f,-0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.643f,-0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.5f,  -0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.5f,   0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 31              //Negative Z Normal     Texture Coords.
        0.643f, 0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.766f, 0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.766f,-0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.766f,-0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.643f,-0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.643f, 0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 32              //Negative Z Normal     Texture Coords.
        0.766f, 0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.866f, 0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.866f,-0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.866f,-0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.766f,-0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.766f, 0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 33              //Negative Z Normal     Texture Coords.
        0.866f, 0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.940f, 0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.940f,-0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.940f,-0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.866f,-0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.866f, 0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 34              //Negative Z Normal     Texture Coords.
        0.940f, 0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        0.985f, 0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        0.985f,-0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.985f,-0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.940f,-0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.940f, 0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        //Rectangle 35              //Negative Z Normal     Texture Coords.
        0.985f, 0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.0f, 1.0f,
        1.0f,  -0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        1.0f,  -0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.0f,
        0.985f,-0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 0.0f,
        0.985f, 0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     1.0f, 1.0f,
        
        // Top Circle
        //Triangle 1                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     1.0f, 0.5f,
        0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.992f, 0.587f,
        //Triangle 2                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.992f, 0.587f,
        0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.970f, 0.671f,
        //Triangle 3                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.970f, 0.671f,
        0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.933f, 0.75f,
        //Triangle 4                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.933f, 0.75f,
        0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.883f, 0.821f,
        //Triangle 5                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.883f, 0.821f,
        0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.821f, 0.883f,
        //Triangle 6                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.821f, 0.883f,
        0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.75f, 0.933f,
        //Triangle 7                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.75f, 0.933f,
        0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.671f, 0.970f,
        //Triangle 8                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.671f, 0.970f,
        0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.587f, 0.992f,
        //Triangle 9                //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.587f, 0.992f,
        0.0f,   0.5f,  1.0f,        0.0f,  0.0f, -1.0f,     0.5f, 1.0f,
        //Triangle 10               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.0f,   0.5f,  1.0f,        0.0f,  0.0f, -1.0f,     0.5f, 1.0f,
       -0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.413f, 0.992f,
        //Triangle 11               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.174f, 0.5f,  0.985f,      0.0f,  0.0f, -1.0f,     0.413f, 0.992f,
       -0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.329f, 0.970f,
        //Triangle 12               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.342f, 0.5f,  0.940f,      0.0f,  0.0f, -1.0f,     0.329f, 0.970f,
       -0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.25f, 0.933f,
        //Triangle 13               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.5f,   0.5f,  0.866f,      0.0f,  0.0f, -1.0f,     0.25f, 0.933f,
       -0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.179f, 0.883f,
        //Triangle 14               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.643f, 0.5f,  0.766f,      0.0f,  0.0f, -1.0f,     0.179f, 0.883f,
       -0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.117f, 0.821f,
        //Triangle 15               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.766f, 0.5f,  0.643f,      0.0f,  0.0f, -1.0f,     0.117f, 0.821f,
       -0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.067f, 0.75f,
        //Triangle 16               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.866f, 0.5f,  0.5f,        0.0f,  0.0f, -1.0f,     0.067f, 0.75f,
       -0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.030f, 0.671f,
        //Triangle 17               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.940f, 0.5f,  0.342f,      0.0f,  0.0f, -1.0f,     0.030f, 0.671f,
       -0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.008f, 0.587f,
        //Triangle 18               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.985f, 0.5f,  0.174f,      0.0f,  0.0f, -1.0f,     0.008f, 0.587f,
       -1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.5f,
        //Triangle 19               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.0f, 0.5f,
       -0.985f, 0.5f,  -0.174f,     0.0f,  0.0f, -1.0f,     0.008f, 0.413f,
        //Triangle 20               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.985f, 0.5f,  -0.174f,     0.0f,  0.0f, -1.0f,     0.008f, 0.413f,
       -0.940f, 0.5f,  -0.342f,     0.0f,  0.0f, -1.0f,     0.030f, 0.330f,
        //Triangle 21               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.940f, 0.5f,  -0.342f,     0.0f,  0.0f, -1.0f,     0.030f, 0.330f,
       -0.866f, 0.5f,  -0.5f,       0.0f,  0.0f, -1.0f,     0.067f, 0.25f,
        //Triangle 22               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.866f, 0.5f,  -0.5f,       0.0f,  0.0f, -1.0f,     0.067f, 0.25f,
       -0.766f, 0.5f,  -0.643f,     0.0f,  0.0f, -1.0f,     0.117f, 0.179f,
        //Triangle 23               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.766f, 0.5f,  -0.643f,     0.0f,  0.0f, -1.0f,     0.117f, 0.179f,
       -0.643f, 0.5f,  -0.766f,     0.0f,  0.0f, -1.0f,     0.179f, 0.117f,
        //Triangle 24               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.643f, 0.5f,  -0.766f,     0.0f,  0.0f, -1.0f,     0.179f, 0.117f,
       -0.5f,   0.5f,  -0.866f,     0.0f,  0.0f, -1.0f,     0.25f, 0.067f,
        //Triangle 25               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.5f,   0.5f,  -0.866f,     0.0f,  0.0f, -1.0f,     0.25f, 0.067f,
       -0.342f, 0.5f,  -0.940f,     0.0f,  0.0f, -1.0f,     0.329f, 0.030f,
        //Triangle 26               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.342f, 0.5f,  -0.940f,     0.0f,  0.0f, -1.0f,     0.329f, 0.030f,
       -0.174f, 0.5f,  -0.985f,     0.0f,  0.0f, -1.0f,     0.413f, 0.008f,
        //Triangle 27               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
       -0.174f, 0.5f,  -0.985f,     0.0f,  0.0f, -1.0f,     0.413f, 0.008f,
        0.0f,   0.5f,  -1.0f,       0.0f,  0.0f, -1.0f,     0.5f, 0.0f,
        //Triangle 28               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.0f,   0.5f,  -1.0f,       0.0f,  0.0f, -1.0f,     0.5f, 0.0f,
        0.174f, 0.5f,  -0.985f,     0.0f,  0.0f, -1.0f,     0.587f, 0.008f,
        //Triangle 28               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.174f, 0.5f,  -0.985f,     0.0f,  0.0f, -1.0f,     0.587f, 0.008f,
        0.342f, 0.5f,  -0.940f,     0.0f,  0.0f, -1.0f,     0.671f, 0.030f,
        //Triangle 29               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.342f, 0.5f, -0.940f,      0.0f,  0.0f, -1.0f,     0.671f, 0.030f,
        0.5f,   0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     0.75f, 0.067f,
        //Triangle 30               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.5f,   0.5f, -0.866f,      0.0f,  0.0f, -1.0f,     0.75f, 0.067f,
        0.643f, 0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     0.821f, 0.117f,
        //Triangle 31               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.643f, 0.5f, -0.766f,      0.0f,  0.0f, -1.0f,     0.821f, 0.117f,
        0.766f, 0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     0.883f, 0.179f,
        //Triangle 32               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.766f, 0.5f, -0.643f,      0.0f,  0.0f, -1.0f,     0.883f, 0.179f,
        0.866f, 0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     0.933f, 0.25f,
        //Triangle 33               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.866f, 0.5f, -0.5f,        0.0f,  0.0f, -1.0f,     0.933f, 0.25f,
        0.940f, 0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     0.970f, 0.329f,
        //Triangle 34               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.940f, 0.5f, -0.342f,      0.0f,  0.0f, -1.0f,     0.970f, 0.329f,
        0.985f, 0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     0.992f, 0.413f,
        //Triangle 35               //Negative Z Normal     Texture Coords.
        0.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     0.5f, 0.5f,
        0.985f, 0.5f, -0.174f,      0.0f,  0.0f, -1.0f,     0.992f, 0.413f,
        1.0f,   0.5f,  0.0f,        0.0f,  0.0f, -1.0f,     1.0f, 0.5f,

        //Bottom Circle
        //Triangle 1                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        1.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      1.0f, 0.5f,
        0.985f, -0.5f, 0.174f,      0.0f, 0.0f, -1.0f,      0.992f, 0.587f,
        //Triangle 2                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.985f, -0.5f, 0.174f,      0.0f, 0.0f, -1.0f,      0.992f, 0.587f,
        0.940f, -0.5f, 0.342f,      0.0f, 0.0f, -1.0f,      0.970f, 0.671f,
        //Triangle 3                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.940f, -0.5f, 0.342f,      0.0f, 0.0f, -1.0f,      0.970f, 0.671f,
        0.866f, -0.5f, 0.5f,        0.0f, 0.0f, -1.0f,      0.933f, 0.75f,
        //Triangle 4                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.866f, -0.5f, 0.5f,        0.0f, 0.0f, -1.0f,      0.933f, 0.75f,
        0.766f, -0.5f, 0.643f,      0.0f, 0.0f, -1.0f,      0.883f, 0.821f,
        //Triangle 5                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.766f, -0.5f, 0.643f,      0.0f, 0.0f, -1.0f,      0.883f, 0.821f,
        0.643f, -0.5f, 0.766f,      0.0f, 0.0f, -1.0f,      0.821f, 0.883f,
        //Triangle 6                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.643f, -0.5f, 0.766f,      0.0f, 0.0f, -1.0f,      0.821f, 0.883f,
        0.5f,   -0.5f, 0.866f,      0.0f, 0.0f, -1.0f,      0.75f, 0.933f,
        //Triangle 7                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.5f,   -0.5f, 0.866f,      0.0f, 0.0f, -1.0f,      0.75f, 0.933f,
        0.342f, -0.5f, 0.940f,      0.0f, 0.0f, -1.0f,      0.671f, 0.970f,
        //Triangle 8                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.342f, -0.5f, 0.940f,      0.0f, 0.0f, -1.0f,      0.671f, 0.970f,
        0.174f, -0.5f, 0.985f,      0.0f, 0.0f, -1.0f,      0.587f, 0.992f,
        //Triangle 9                //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.174f, -0.5f, 0.985f,      0.0f, 0.0f, -1.0f,      0.587f, 0.992f,
        0.0f,   -0.5f, 1.0f,        0.0f, 0.0f, -1.0f,      0.5f, 1.0f,
        //Triangle 10               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.0f,   -0.5f, 1.0f,        0.0f, 0.0f, -1.0f,      0.5f, 1.0f,
       -0.174f, -0.5f, 0.985f,      0.0f, 0.0f, -1.0f,      0.413f, 0.992f,
        //Triangle 11               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.174f, -0.5f, 0.985f,      0.0f, 0.0f, -1.0f,      0.413f, 0.992f,
       -0.342f, -0.5f, 0.940f,      0.0f, 0.0f, -1.0f,      0.329f, 0.970f,
        //Triangle 12               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.342f, -0.5f, 0.940f,      0.0f, 0.0f, -1.0f,      0.329f, 0.970f,
       -0.5f,   -0.5f, 0.866f,      0.0f, 0.0f, -1.0f,      0.25f, 0.933f,
        //Triangle 13               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.5f,   -0.5f, 0.866f,      0.0f, 0.0f, -1.0f,      0.25f, 0.933f,
       -0.643f, -0.5f, 0.766f,      0.0f, 0.0f, -1.0f,      0.179f, 0.883f,
       //Triangle 14               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.643f, -0.5f, 0.766f,      0.0f, 0.0f, -1.0f,      0.179f, 0.883f,
       -0.766f, -0.5f, 0.643f,      0.0f, 0.0f, -1.0f,      0.117f, 0.821f,
        //Triangle 15               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.766f, -0.5f, 0.643f,      0.0f, 0.0f, -1.0f,      0.117f, 0.821f,
       -0.866f, -0.5f, 0.5f,        0.0f, 0.0f, -1.0f,      0.067f, 0.75f,
        //Triangle 16               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.866f, -0.5f, 0.5f,        0.0f, 0.0f, -1.0f,      0.067f, 0.75f,
       -0.940f, -0.5f, 0.342f,      0.0f, 0.0f, -1.0f,      0.030f, 0.671f,
        //Triangle 17               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.940f, -0.5f, 0.342f,      0.0f, 0.0f, -1.0f,      0.030f, 0.671f,
       -0.985f, -0.5f, 0.174f,      0.0f, 0.0f, -1.0f,      0.008f, 0.587f,
        //Triangle 18               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.985f, -0.5f, 0.174f,      0.0f, 0.0f, -1.0f,      0.008f, 0.587f,
       -1.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.0f, 0.5f,
        //Triangle 19               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -1.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.0f, 0.5f,
       -0.985f, -0.5f, -0.174f,     0.0f, 0.0f, -1.0f,      0.008f, 0.413f,
        //Triangle 20               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.985f, -0.5f, -0.174f,     0.0f, 0.0f, -1.0f,      0.008f, 0.413f,
       -0.940f, -0.5f, -0.342f,     0.0f, 0.0f, -1.0f,      0.030f, 0.330f,
        //Triangle 21               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.940f, -0.5f, -0.342f,     0.0f, 0.0f, -1.0f,      0.030f, 0.330f,
       -0.866f, -0.5f, -0.5f,       0.0f, 0.0f, -1.0f,      0.067f, 0.25f,
        //Triangle 22               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.866f, -0.5f, -0.5f,       0.0f, 0.0f, -1.0f,      0.067f, 0.25f,
       -0.766f, -0.5f, -0.643f,     0.0f, 0.0f, -1.0f,      0.117f, 0.179f,
        //Triangle 23               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.766f, -0.5f, -0.643f,     0.0f, 0.0f, -1.0f,      0.117f, 0.179f,
       -0.643f, -0.5f, -0.766f,     0.0f, 0.0f, -1.0f,      0.179f, 0.117f,
        //Triangle 24               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.643f, -0.5f, -0.766f,     0.0f, 0.0f, -1.0f,      0.179f, 0.117f,
       -0.5f,   -0.5f, -0.866f,     0.0f, 0.0f, -1.0f,      0.25f, 0.067f,
        //Triangle 25               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.5f,   -0.5f, -0.866f,     0.0f, 0.0f, -1.0f,      0.25f, 0.067f,
       -0.342f, -0.5f, -0.940f,     0.0f, 0.0f, -1.0f,      0.329f, 0.030f,
        //Triangle 26               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.342f, -0.5f, -0.940f,     0.0f, 0.0f, -1.0f,      0.329f, 0.030f,
       -0.174f, -0.5f, -0.985f,     0.0f, 0.0f, -1.0f,      0.413f, 0.008f,
        //Triangle 27               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
       -0.174f, -0.5f, -0.985f,     0.0f, 0.0f, -1.0f,      0.413f, 0.008f,
        0.0f,   -0.5f, -1.0f,       0.0f, 0.0f, -1.0f,      0.5f, 0.0f,
        //Triangle 28               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.0f,   -0.5f, -1.0f,       0.0f, 0.0f, -1.0f,      0.5f, 0.0f,
        0.174f, -0.5f, -0.985f,     0.0f, 0.0f, -1.0f,      0.587f, 0.008f,
        //Triangle 28               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.174f, -0.5f, -0.985f,     0.0f, 0.0f, -1.0f,      0.587f, 0.008f,
        0.342f, -0.5f, -0.940f,     0.0f, 0.0f, -1.0f,      0.671f, 0.030f,
        //Triangle 29               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.342f, -0.5f, -0.940f,     0.0f, 0.0f, -1.0f,      0.671f, 0.030f,
        0.5f,   -0.5f, -0.866f,     0.0f, 0.0f, -1.0f,      0.75f, 0.067f,
        //Triangle 30               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.5f,   -0.5f, -0.866f,     0.0f, 0.0f, -1.0f,      0.75f, 0.067f,
        0.643f, -0.5f, -0.766f,     0.0f, 0.0f, -1.0f,      0.821f, 0.117f,
        //Triangle 31               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.643f, -0.5f, -0.766f,     0.0f, 0.0f, -1.0f,      0.821f, 0.117f,
        0.766f, -0.5f, -0.643f,     0.0f, 0.0f, -1.0f,      0.883f, 0.179f,
        //Triangle 32               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.766f, -0.5f, -0.643f,     0.0f, 0.0f, -1.0f,      0.883f, 0.179f,
        0.866f, -0.5f, -0.5f,       0.0f, 0.0f, -1.0f,      0.933f, 0.25f,
        //Triangle 33               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.866f, -0.5f, -0.5f,       0.0f, 0.0f, -1.0f,      0.933f, 0.25f,
        0.940f, -0.5f, -0.342f,     0.0f, 0.0f, -1.0f,      0.970f, 0.329f,
        //Triangle 34               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.940f, -0.5f, -0.342f,     0.0f, 0.0f, -1.0f,      0.970f, 0.329f,
        0.985f, -0.5f, -0.174f,     0.0f, 0.0f, -1.0f,      0.992f, 0.413f,
        //Triangle 35               //Negative Z Normal     Texture Coords.
        0.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      0.5f, 0.5f,
        0.985f, -0.5f, -0.174f,     0.0f, 0.0f, -1.0f,      0.992f, 0.413f,
        1.0f,   -0.5f, 0.0f,        0.0f, 0.0f, -1.0f,      1.0f, 0.5f,
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateCubeMesh function
void UCreateCubeMesh(GLMesh& mesh)
{
    // Position and Color data
    GLfloat verts[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

       //Front Face         //Positive Z Normal
      -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
       0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
       0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
      -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
      -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,

      //Left Face          //Negative X Normal
     -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
     -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
     -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
     -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

     //Right Face         //Positive X Normal
     0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
     0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

     //Bottom Face        //Negative Y Normal
    -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
     0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

    //Top Face           //Positive Y Normal
   -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
    0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
    0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
    0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
   -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
   -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateCubeTorusMesh function
void UCreateCubeTorusMesh(GLMesh& mesh)
{
    // Position and Color data
    GLfloat verts[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
      -1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
       1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
      -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
      -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
       1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.75f,
       0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.75f,
       1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
       0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
       1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
       1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
       0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
      -1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
      -1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
       0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
      -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.25f,
      -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.25f,
      -1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
      -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
      -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
      -1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
      -1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,

       //Front Face         //Positive Z Normal
      -1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
       1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
      -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
      -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
       1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.75f,
       0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.75f,
       1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
       0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
       1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
       1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
       0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
      -1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
      -1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
       0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
      -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.25f,
      -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.25f,
      -1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
      -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
      -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
      -1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
      -1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,

      //Left Face          //Negative X Normal
     -1.0f,  1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
     -1.0f,  1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
     -1.0f, -1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     -1.0f, -1.0f, -1.0f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     -1.0f, -1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
     -1.0f,  1.0f,  1.0f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

     //Right Face         //Positive X Normal
     1.0f,  1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
     1.0f,  1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
     1.0f, -1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     1.0f, -1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     1.0f, -1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
     1.0f,  1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

     //Bottom Face        //Negative Y Normal
    -1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
     1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
     1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
     1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
    -1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
    -1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

    //Top Face           //Positive Y Normal
   -1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
    1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
    1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
    1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
   -1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
   -1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,

    //Hole top
   -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.25f,
   -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
    0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
    0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
    0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.75f,
   -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
    
    //Hole right
    0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
    0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.75f,
    0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.25f,
    0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.25f,
    0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
    0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.75f,

    //Hole bottom
   -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.25f,
   -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,
    0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
    0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.25f,
    0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.75f, 0.75f,
   -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.25f, 0.75f,

    //Hole left
   -0.5f, 0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.25f, 0.75f,
   -0.5f, 0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.75f, 0.75f,
   -0.5f, -0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.25f, 0.25f,
   -0.5f, -0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.25f, 0.25f,
   -0.5f, -0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.25f, 0.75f,
   -0.5f, 0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.75f, 0.75f,
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, &mesh.vbo);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

void setupObject() {
    // camera/view transformation
    view = gCamera.GetViewMatrix();

    // Creates a perspective projection
    projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gObjectProgramId, "model");
    viewLoc = glGetUniformLocation(gObjectProgramId, "view");
    projLoc = glGetUniformLocation(gObjectProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
}

void setupObjectColor(glm::vec3 gObjectColor, glm::vec3 gLightColor, glm::vec3 gLightPosition) {
    // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
    objectColorLoc = glGetUniformLocation(gObjectProgramId, "objectColor");
    lightColorLoc = glGetUniformLocation(gObjectProgramId, "lightColor");
    lightPositionLoc = glGetUniformLocation(gObjectProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gObjectProgramId, "viewPosition");

    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
}

void setupLight() {
    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
}