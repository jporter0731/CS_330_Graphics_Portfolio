#include "Cube.h"

//Setup the variables required for the cube object

Cube::Cube(double xScale, double yScale, double zScale, double xLoc, double yLoc, double zLoc, double rColor, double gColor, double bColor)
{
	gScale = glm::vec3(xScale, yScale, zScale);
	gPosition = glm::vec3(xLoc, yLoc, zLoc);
	this->gColor = glm::vec3(rColor, gColor, bColor);
}

float Cube::degreesToRadians(float degreeAngle)
{
	float radianAngle = degreeAngle * (3.1415 * 180.0);
	return radianAngle;
}

glm::mat4 Cube::moveCube(float xAngle, float yAngle, float zAngle)
{
	//Change the angle
	glm::mat4 xRotation = glm::rotate(degreesToRadians(xAngle), glm::vec3(1.0, 0.0f, 0.0f));
	glm::mat4 yRotation = glm::rotate(degreesToRadians(yAngle), glm::vec3(0.0, 1.0f, 0.0f));
	glm::mat4 zRotation = glm::rotate(degreesToRadians(zAngle), glm::vec3(0.0, 0.0f, 1.0f));

	//Move the object to a giveen location and size
	glm::mat4 model = glm::translate(gPosition) * xRotation * yRotation * zRotation * glm::scale(gScale);
	return model;
}

glm::vec3 Cube::getObjectColor()
{
	return gColor;
}